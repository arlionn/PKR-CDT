This codes are written by Lixiong Yang, contac to:lixiongyang@tom.conm / ylx@lzu.edu.cn

Eestimate the PKR-CDT model proposed in
Panel Kink Regression Model with a Covariate-Dependent Threshold